package com.example.graficzne;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Figura[] figury;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        figury = new Figura[6];
        for (int i = 0; i < figury.length; i++) {
            int resID = getResources().getIdentifier("view" + (i + 1), "id", getPackageName());
            figury[i] = findViewById(resID);
        }
    }
}
