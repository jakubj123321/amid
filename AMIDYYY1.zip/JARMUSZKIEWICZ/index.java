package org.example.animacja;

import javafx.animation.Animation;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HelloApplication extends Application {

    @Override
    public void start(Stage primaryStage) {
        Pane root = new Pane();
        Scene scene = new Scene(root, 400, 400, Color.WHITE);

        Rectangle square = new Rectangle(50, 50, 50, 50);
        square.setFill(Color.BLUE);

        TranslateTransition transition = new TranslateTransition(Duration.seconds(2), square);
        transition.setToX(300);
        transition.setAutoReverse(true);
        transition.setCycleCount(Animation.INDEFINITE);

        Button startButton = new Button("START");
        startButton.setLayoutX(50);
        startButton.setLayoutY(350);
        startButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                transition.play();
            }
        });

        Button stopButton = new Button("STOP");
        stopButton.setLayoutX(150);
        stopButton.setLayoutY(350);
        stopButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                transition.stop();
            }
        });

        Button infoButton = new Button("TWÓRCA");
        infoButton.setLayoutX(250);
        infoButton.setLayoutY(350);
        infoButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("TWÓRCA");
                alert.setHeaderText(null);
                alert.setContentText("Twórca: Jakub Jarmuszkiewicz");
                alert.showAndWait();
            }
        });

        root.getChildren().addAll(square, startButton, stopButton, infoButton);

        primaryStage.setTitle("Animacja");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}