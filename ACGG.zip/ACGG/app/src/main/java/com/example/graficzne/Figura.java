package com.example.graficzne;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class Figura extends View {

    private Random randomGenerator;
    private int[] colors;
    private int[] sizes;
    private int shapeCount;

    public Figura(Context context, AttributeSet attrs) {
        super(context, attrs);
        randomGenerator = new Random();
        initializeShapes();
    }


    private void initializeShapes() {
        shapeCount = 5 + randomGenerator.nextInt(6);
        colors = new int[shapeCount];
        sizes = new int[shapeCount];


        for (int i = 0; i < shapeCount; i++) {
            colors[i] = Color.argb(255, randomGenerator.nextInt(256), randomGenerator.nextInt(256), randomGenerator.nextInt(256));
            sizes[i] = 50 + randomGenerator.nextInt(150);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        Paint paint = new Paint();
        paint.setAntiAlias(true);


        paint.setColor(Color.GRAY);
        canvas.drawRect(0, 0, width, height, paint);

        CharSequence description = getContentDescription();
        if (description == null) {
            description = "brak";
        }


        for (int i = 0; i < shapeCount; i++) {
            paint.setColor(colors[i]);
            int size = sizes[i];
            int x = randomGenerator.nextInt(width - size);
            int y = randomGenerator.nextInt(height - size);

            switch (description.toString()) {
                case "koło":
                    canvas.drawCircle(x + size / 2, y + size / 2, size / 2, paint);
                    break;
                case "elipsa":
                    RectF oval = new RectF(x, y, x + size, y + size / 2);
                    canvas.drawOval(oval, paint);
                    break;
                case "prostokąt":
                    RectF rect = new RectF(x, y, x + size, y + size);
                    canvas.drawRect(rect, paint);
                    break;
                case "prostokąt okrągły":
                    RectF roundRect = new RectF(x, y, x + size, y + size);
                    canvas.drawRoundRect(roundRect, 20, 20, paint);
                    break;
                case "łuk":
                    RectF arcRect = new RectF(x, y, x + size, y + size);
                    canvas.drawArc(arcRect, randomGenerator.nextInt(360), randomGenerator.nextInt(180), false, paint);
                    break;
                case "linia":
                    int dx = randomGenerator.nextInt(width);
                    int dy = randomGenerator.nextInt(height);
                    canvas.drawLine(x, y, dx, dy, paint);
                    break;
            }
        }


        paint.setTextSize(50);
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setColor(Color.BLUE);
        canvas.drawText((String) description, width - 20, height / 2, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            initializeShapes();
            invalidate();
            return true;
        }
        return super.onTouchEvent(event);
    }
}

